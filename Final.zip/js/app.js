/* =========================================================
   GLOBAL STATE
   ========================================================= */

let portrait = true;

/* =========================================================
   DOM REFERENCES
   ========================================================= */

const pageUrl = document.getElementById("pageUrl");
const goBtn = document.getElementById("goBtn");
const resetBtn = document.getElementById("resetBtn");
const rotateBtn = document.getElementById("rotateBtn");
const exportAllBtn = document.getElementById("exportAllBtn");

/* =========================================================
   DEVICE LIST (LOCKED – NEVER REMOVE)
   ========================================================= */

const DEVICES = [

  /* 🖥️ Desktop */
  { group:"desktop", name:"Desktop 1080p", w:1920, h:1080 },
  { group:"desktop", name:"Desktop 1440p", w:2560, h:1440 },
  { group:"desktop", name:"Laptop (1366×768)", w:1366, h:768 },
  { group:"desktop", name:"MacBook (1440×900)", w:1440, h:900 },

  /* 🍎 iOS */
  { group:"phone", name:"iPhone 16 Pro Max", w:1320, h:2868 },
  { group:"phone", name:"iPhone 16 Pro", w:1206, h:2622 },
  { group:"phone", name:"iPhone 16", w:1179, h:2556 },
  { group:"phone", name:"iPhone 15 / 14 Pro", w:1179, h:2556 },
  { group:"phone", name:"iPhone 15 Pro Max / 14 Pro Max", w:1290, h:2796 },
  { group:"phone", name:"iPhone 14 / 13 Pro", w:1170, h:2532 },
  { group:"phone", name:"iPhone 14 Pro Max / 13 Pro Max", w:1284, h:2778 },
  { group:"phone", name:"iPhone 13 mini / 12 mini", w:1080, h:2340 },
  { group:"phone", name:"iPhone 12 / 12 Pro", w:1170, h:2532 },
  { group:"phone", name:"iPhone 11 Pro Max / XS Max", w:1242, h:2688 },
  { group:"phone", name:"iPhone 11 Pro / XS / X", w:1125, h:2436 },
  { group:"phone", name:"iPhone 11 / XR", w:828, h:1792 },
  { group:"phone", name:"iPhone 8 Plus / 7 Plus", w:1080, h:1920 },
  { group:"phone", name:"iPhone SE (3rd Gen)", w:750, h:1334 },

  /* 🤖 Android */
  { group:"phone", name:"Samsung Galaxy S24 Ultra", w:1440, h:3120 },
  { group:"phone", name:"Samsung Galaxy S24 / S23", w:1080, h:2340 },
  { group:"phone", name:"Google Pixel 8 Pro", w:1344, h:2992 },
  { group:"phone", name:"Google Pixel 8", w:1080, h:2400 },
  { group:"phone", name:"OnePlus 12", w:1440, h:3168 },
  { group:"phone", name:"Samsung Galaxy Z Fold 5 (Cover Screen)", w:904, h:2316 },
  { group:"phone", name:"Android FHD+ (1080×2400)", w:1080, h:2400 },
  { group:"phone", name:"Android QHD+ (1440×3200)", w:1440, h:3200 },
  { group:"phone", name:"Android Mid-range (1080×2340)", w:1080, h:2340 },
  { group:"phone", name:"Android Budget HD+ (720×1600)", w:720, h:1600 },
  { group:"phone", name:"Foldable Inner Screen", w:2208, h:1768 },

  /* 📊 Tablets */
  { group:"tablet", name:"iPad Viewport (768×1024)", w:768, h:1024 },
  { group:"tablet", name:"Modern iPad Viewport (820×1180)", w:820, h:1180 },
  { group:"tablet", name:"iPad Air / Mini", w:1536, h:2048 },
  { group:"tablet", name:"iPad Pro", w:2048, h:2732 },
  { group:"tablet", name:"Android Tablet (1280×800)", w:1280, h:800 }
];

/* =========================================================
   GROUP CONTAINERS
   ========================================================= */

const groups = {
  desktop: document.getElementById("desktopGroup"),
  phone: document.getElementById("phoneGroup"),
  tablet: document.getElementById("tabletGroup")
};

/* =========================================================
   DEFAULT PAGE
   ========================================================= */

pageUrl.value = "https://en.wikipedia.org";

/* =========================================================
   HEADER ACTIONS
   ========================================================= */

goBtn.onclick = () => render();
resetBtn.onclick = () => render();

rotateBtn.onclick = () => {
  portrait = !portrait;
  render();
};

pageUrl.addEventListener("keydown", e => {
  if (e.key === "Enter") render();
});

/* =========================================================
   TAB SWITCHING
   ========================================================= */

function setupTabs() {
  const tabBtns = document.querySelectorAll(".tab-btn");
  const tabContents = document.querySelectorAll(".tab-content");

  tabBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      tabBtns.forEach(b => b.classList.remove("active"));
      tabContents.forEach(c => c.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(btn.dataset.target).classList.add("active");
    });
  });
}

/* =========================================================
   RENDER (🔥 REAL PREVIEW – NO SRCdoc)
   ========================================================= */

function render() {
  Object.values(groups).forEach(g => { if (g) g.innerHTML = ""; });

  let finalUrl = pageUrl.value;
  const isExternal = finalUrl.startsWith("http://") || finalUrl.startsWith("https://");

  // External sites (like ASP.NET servers) can crash if unexpected parameters are appended.
  if (!isExternal) {
    const cacheBuster = (finalUrl.includes("?") ? "&" : "?") + "t=" + Date.now();
    finalUrl += cacheBuster;
  }

  DEVICES.forEach(device => {
    const w = portrait ? device.w : device.h;
    const h = portrait ? device.h : device.w;

    const card = document.createElement("div");
    card.className = "device";

    card.innerHTML =
      `<strong>${device.name} — ${w}×${h}</strong>`;

    const iframe = document.createElement("iframe");
    iframe.width = w;
    iframe.height = h;
    iframe.loading = "lazy";
    iframe.src = finalUrl;

    card.appendChild(iframe);
    if (groups[device.group]) {
      groups[device.group].appendChild(card);
    }
  });
}

/* =========================================================
   📦 ZIP EXPORT (IFRAME-EXACT, DEVICE FOLDERS)
   ========================================================= */

exportAllBtn.onclick = async () => {
  const frames = document.querySelectorAll("iframe");
  if (!frames.length) return alert("Nothing to export");

  const zip = new JSZip();
  const ts = new Date().toISOString().replace(/[:.]/g, "-");

  for (let i = 0; i < frames.length; i++) {
    const iframe = frames[i];
    const device = DEVICES[i];

    try {
      await new Promise(res => setTimeout(res, 300));

      const rect = iframe.getBoundingClientRect();

      const wrapper = document.createElement("div");
      wrapper.style.position = "fixed";
      wrapper.style.left = "-100000px";
      wrapper.style.width = rect.width + "px";
      wrapper.style.height = rect.height + "px";
      wrapper.style.background = "#fff";

      const clone = iframe.cloneNode(true);
      clone.style.width = rect.width + "px";
      clone.style.height = rect.height + "px";

      wrapper.appendChild(clone);
      document.body.appendChild(wrapper);

      const canvas = await html2canvas(wrapper, {
        backgroundColor: "#ffffff",
        scale: 1,
        useCORS: true
      });

      document.body.removeChild(wrapper);

      zip
        .folder(device.group)
        .file(
          `${device.name}.png`,
          canvas.toDataURL("image/png").split(",")[1],
          { base64: true }
        );

    } catch (e) {
      console.warn("Export failed:", device.name);
    }
  }

  const blob = await zip.generateAsync({ type: "blob" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `screenshots_${ts}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
};

/* =========================================================
   INIT
   ========================================================= */

setupTabs();
render();
